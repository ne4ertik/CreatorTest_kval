﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace StudentsTest
{
    public partial class Test_form : Form
    {
        private int _currentQuestionIndex = 0;
        private List<Question> _questions;
        private int _score = 0;
        private int _userId;
        private int _testId;
        private string _testFilePath; 


    GroupBox rbGroup;
      
        public Test_form(int userId, int testId, string testFilePath)
        {
            InitializeComponent();

            _userId = userId;
            _testId = testId;
            _testFilePath = testFilePath;

          

            // Настройка GroupBox для вариантов ответов
            rbGroup = new GroupBox();
            rbGroup.Text = "Варианты ответов";
            rbGroup.Font = new Font("Bahnschrift SemiBold", 13F, FontStyle.Bold);
            rbGroup.Size = new Size(500, 200);
            rbGroup.Location = new Point(30, 80);

            this.Controls.Add(rbGroup);



            // Загрузка теста
            LoadTest(testFilePath);

            // Показать первый вопрос
            ShowQuestion(_currentQuestionIndex);
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            Environment.Exit(0);
        }

        private void LoadTest(string filePath)
        {
            try
            {
                var serializer = new XmlSerializer(typeof(Test));
                using (var stream = File.OpenRead(filePath))
                {
                    var test = (Test)serializer.Deserialize(stream);
                    _questions = test.Questions;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки теста: {ex.Message}");
                this.Close();
            }
        }

        private void ShowQuestion(int index)
        {
            
            rbGroup.Controls.Clear();

            if (index >= _questions.Count) return;

            var question = _questions[index];
            label_TextQueastion.Text = question.Text;

            // Добавляем варианты ответов
            int yPos = 20;
            for (int i = 0; i < question.Options.Count; i++)
            {
                RadioButton rb = new RadioButton();
                rb.Text = question.Options[i];
                rb.Font = new Font("Bahnschrift SemiBold", 12F, FontStyle.Bold);
                rb.Location = new Point(20, yPos);
                rb.AutoSize = true;
                rb.Tag = i; // Сохраняем индекс варианта ответа
                rbGroup.Controls.Add(rb);

                yPos += 30;
            }

            // Обновляем текст кнопки если это последний вопрос
            if (index == _questions.Count - 1)
            {
                button1.Text = "Завершить тест";
            }
            else
            {
                button1.Text = "Следующий вопрос";
            }
        }
        private void Test_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Проверяем выбран ли ответ
            bool answerSelected = false;
            int selectedAnswerIndex = -1;

            foreach (Control control in rbGroup.Controls)
            {
                if (control is RadioButton rb && rb.Checked)
                {
                    answerSelected = true;
                    selectedAnswerIndex = (int)rb.Tag;
                    break;
                }
            }

            if (!answerSelected)
            {
                MessageBox.Show("Выберите вариант ответа!");
                return;
            }

            // Проверяем правильность ответа
            var currentQuestion = _questions[_currentQuestionIndex];
            if (selectedAnswerIndex == currentQuestion.CorrectOptionIndex)
            {
                _score += currentQuestion.Points;
            }

            // Переходим к следующему вопросу или завершаем тест
            if (_currentQuestionIndex < _questions.Count - 1)
            {
                _currentQuestionIndex++;
                ShowQuestion(_currentQuestionIndex);
            }
            else
            {
                // Вычисляем процент правильных ответов
                int totalPossibleScore = _questions.Sum(q => q.Points);
                double percentage = (_score * 100.0) / totalPossibleScore;

                // Определяем оценку
                int mark;
                if (percentage >= 90) mark = 5;
                else if (percentage >= 75) mark = 4;
                else if (percentage >= 50) mark = 3;
                else mark = 2;

                // Сохраняем результаты в БД
                SaveTestResult(mark, _questions.Count, _score);

                // Показываем форму с результатами
                Result resultForm = new Result(mark);
                resultForm.Show();
                this.Show();


                
            }
        }

        private void SaveTestResult(int mark, int questionsCount, int score)
        {
            try
            {
                using (OleDbConnection conn = new OleDbConnection(
                    @"Provider=Microsoft.ACE.OLEDB.16.0;Data Source=C:\My works for college\CreatorTestForTeacher\DataBaseTestSchool.accdb"))
                {
                    conn.Open();

                    // 1. Получаем следующий ID для оценки
                    int nextMarkId = 1;
                    using (OleDbCommand cmd = new OleDbCommand("SELECT MAX(ID_mark) FROM Оценки", conn))
                    {
                        object result = cmd.ExecuteScalar();
                        if (result != DBNull.Value)
                        {
                            nextMarkId = Convert.ToInt32(result) + 1;
                        }
                    }

                    // 2. Вставляем данные в таблицу Оценки
                    string insertQuery = @"INSERT INTO Оценки 
                                (ID_mark, Ученик, Тест, Оценка, [Пройдено вопросов], 
                                [Количество набранных баллов], [Дата_прохождения]) 
                                VALUES (@id, @student, @test, @mark, @questions, @score, @date)";

                    using (OleDbCommand cmd = new OleDbCommand(insertQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", nextMarkId);
                        cmd.Parameters.AddWithValue("@student", _userId);
                        cmd.Parameters.AddWithValue("@test", _testId);
                        cmd.Parameters.AddWithValue("@mark", mark);
                        cmd.Parameters.AddWithValue("@questions", questionsCount);
                        cmd.Parameters.AddWithValue("@score", score);
                        cmd.Parameters.AddWithValue("@date", DateTime.Now.ToString("dd.MM.yyyy"));

                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения результатов: {ex.Message}", "Ошибка",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
    }


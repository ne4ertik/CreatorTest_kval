﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentsTest
{
    [Serializable]
    public class Test
    {
        public int TeacherId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public List<Question> Questions { get; set; } = new List<Question>();

        public int TotalPoints
        {
            get { return Questions.Sum(q => q.Points); }
        }
    }

    [Serializable]
    public class Question
    {
        public string Text { get; set; }
        public List<string> Options { get; set; } = new List<string>();
        public int CorrectOptionIndex { get; set; }
        public int Points { get; set; } = 1;
    }

}

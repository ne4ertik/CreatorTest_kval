﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentsTest
{
    public partial class Result : Form
    {
       
        public Result(int mark)
        {
            InitializeComponent();



            label_mark.Text=mark.ToString();

            string imagePath;

            if (mark >= 4)
            {
                imagePath = @"C:\My works for college\StudentsTest\Resources\good.png"; // Путь к изображению для хорошего результата
               
            }
            else
            {
                imagePath = @"C:\My works for college\StudentsTest\Resources\bad.png"; // Путь к изображению для плохого результата
              
            }

            pictureBox1.Image = Image.FromFile(imagePath);

        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            Environment.Exit(0);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
